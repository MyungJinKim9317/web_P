package spring.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring.model.ProfileDto;
import spring.model.Sub_tagDto;
import spring.model.TagDto;
import spring.model.UserDto;

@Service
public class ProfileService {
	@Autowired
	ProfileDao dao;

	public void setDao(ProfileDao dao) {
		this.dao = dao;
	}

	public void updateintro(Map<String, String> map) {
		dao.updateintro(map);
	}

	public void updatetag(ProfileDto dto) {
		dao.updatetag(dto);
	}

	public List<TagDto> selectTags() {
		return dao.selectTags();
	}

	public List<Sub_tagDto> selectSub_tags(int tag_no) {
		return dao.selectSub_tags(tag_no);
	}

	public void updateImage(UserDto dto) {
		dao.updateImage(dto);
	}

	public void updateskill(ProfileDto dto) {
		dao.updateskill(dto);
	}

	public Sub_tagDto selectTag(int no) {
		return dao.selectTag(no);
	}

//	public List<Map<String, Object>> selectEmps(int deptno) {
//		return dao.selectEmps(deptno);
//	}
//
//	public ProfileDto selectEmpOne(int empno) {
//		return dao.selectEmpOne(empno);
//	}

}