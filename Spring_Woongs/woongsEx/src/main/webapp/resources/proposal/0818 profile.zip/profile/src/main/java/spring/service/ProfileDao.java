package spring.service;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import spring.model.ProfileDto;
import spring.model.Sub_tagDto;
import spring.model.TagDto;
import spring.model.UserDto;

public class ProfileDao extends SqlSessionDaoSupport {

	public void updateintro(Map<String, String> map) {
		getSqlSession().update("profile.updateintro", map);
	}

	public void updatetag(ProfileDto dto) {
		getSqlSession().update("profile.updatetag", dto);
	}

	public List<TagDto> selectTags() {
		return getSqlSession().selectList("profile.tags");
	}

	public List<Sub_tagDto> selectSub_tags(int tag_no) {
		return getSqlSession().selectList("profile.sub_tags", tag_no);
	}

	public void updateImage(UserDto dto) {
		// TODO Auto-generated method stub
		getSqlSession().update("profile.updateImage", dto);
	}

	public void updateskill(ProfileDto dto) {
		getSqlSession().update("profile.updateskill", dto);
	}

	public Sub_tagDto selectTag(int no) {
		return getSqlSession().selectOne("profile.sub_tagOne", no);
		
	}

}