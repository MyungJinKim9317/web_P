package spring.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import spring.model.ProfileDto;
import spring.model.Sub_tagDto;
import spring.model.TagDto;
import spring.model.UserDto;
import spring.service.ProfileService;

@Controller
public class ProfileController {

	@Autowired
	ProfileService profile;

	@RequestMapping("/IntroductionForm")
	public String form(ProfileDto dto) {
		return "IntroductionForm";
	}

	@RequestMapping("/intro")
	public String pulsIntro(String nick_name, String introduce, MultipartFile report, HttpServletRequest request) {
		Map<String, String> map = new HashMap<String, String>();

		String path = "C:\\Users\\gusql\\Documents\\workspace-spring-tool-suite-4-4.7.0.RELEASE\\profile\\src\\main\\webapp\\resources\\Images";
		String alterpath = "resources\\Images\\";

		File file = new File(path);

		if (!file.exists()) {
			file.mkdirs();
		}

		path += "\\" + report.getOriginalFilename();
		alterpath += report.getOriginalFilename();

		file = new File(path);

		try {
			report.transferTo(file);
		} catch (IllegalStateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String user_id = "jun";

		map.put("nick_name", nick_name);
		map.put("introduce", introduce);
		map.put("image", alterpath);
		map.put("user_id", user_id);

		profile.updateintro(map);

		return "specialForm";
	}

	@RequestMapping(value = "/image", method = RequestMethod.POST)
	public String insertPost(UserDto dto, MultipartFile report, HttpServletRequest request) {

		String path = "C:\\Users\\gusql\\Documents\\workspace-spring-tool-suite-4-4.7.0.RELEASE\\profile\\src\\main\\webapp\\resources\\Images";
		String alterpath = "resources\\Images\\";

		File file = new File(path);

		if (!file.exists()) {
			file.mkdirs();
		}

		path += "\\" + report.getOriginalFilename();
		alterpath += report.getOriginalFilename();

		file = new File(path);

		try {
			report.transferTo(file);
		} catch (IllegalStateException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// String user_id = (String) request.getSession().getAttribute("user_id");
		dto.setImage(alterpath);

		profile.updateImage(dto);

		return "IntroductionForm";
	}

	@RequestMapping(value = "/tags", method = RequestMethod.POST)
	public void tagList(HttpServletResponse resp) throws Exception {
		List<TagDto> list = profile.selectTags();
		Gson json = new Gson();
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out = resp.getWriter();
		out.print(json.toJson(list));
	}

	@RequestMapping(value = "/sub_tags", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String tagList(int tag_no) throws Exception {
		List<Sub_tagDto> list = profile.selectSub_tags(tag_no);

		Gson json = new Gson();
		System.out.println(json);
		return json.toJson(list);
	}

	@RequestMapping(value = "/sub_tagOne", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String sub_tagOne(int no) throws Exception {
		Sub_tagDto list = profile.selectTag(no);
		Gson json = new Gson();
		System.out.println("ss");
		
		System.out.println(json.toJson(list));
		return json.toJson(list); 
	}

	@RequestMapping(value = "/specialtag", method = RequestMethod.POST)
	public String pulsUpdate(int tag, int sub_tag, HttpServletRequest request) {
		ProfileDto dto = new ProfileDto();
//		String user_id = (String) request.getSession().getAttribute("user_id");
		String user_id = "jun";
		dto.setUser_id(user_id);
		dto.setTag(tag);
		dto.setSub_tag(sub_tag);

		profile.updatetag(dto);

		return "skillForm";
	}

	@RequestMapping("/skill")
	public String pulsSkill(String skill) {
		ProfileDto dto = new ProfileDto();

		String user_id = "jun";
		dto.setUser_id(user_id);
		dto.setSkill(skill);

		profile.updateskill(dto);

		return "skillForm";
	}

}