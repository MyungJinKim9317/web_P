package spring.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TagDto {

	int no;
	String name;

}
