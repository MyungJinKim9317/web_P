package spring.model;

public class PostDto {

	int no;
	String user_id = "test";
	int categoty_first;
	int categoty_second;
	String thumbnail;
	String title;
	String description;
	int price;
	int worksime;
	int retouch_count;
	String service_description;
	String requirement;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public int getCategoty_first() {
		return categoty_first;
	}

	public void setCategoty_first(int categoty_first) {
		this.categoty_first = categoty_first;
	}

	public int getCategoty_second() {
		return categoty_second;
	}

	public void setCategoty_second(int categoty_second) {
		this.categoty_second = categoty_second;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getWorksime() {
		return worksime;
	}

	public void setWorksime(int worksime) {
		this.worksime = worksime;
	}

	public int getRetouch_count() {
		return retouch_count;
	}

	public void setRetouch_count(int retouch_count) {
		this.retouch_count = retouch_count;
	}

	public String getService_description() {
		return service_description;
	}

	public void setService_description(String service_description) {
		this.service_description = service_description;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

}
