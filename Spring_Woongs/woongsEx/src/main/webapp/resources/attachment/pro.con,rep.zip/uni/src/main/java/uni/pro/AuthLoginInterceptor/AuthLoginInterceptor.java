package uni.pro.AuthLoginInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class AuthLoginInterceptor extends HandlerInterceptorAdapter{
	  
  
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        
        HttpSession session = request.getSession();
       
        Object obj = session.getAttribute("login");
        String uri = request.getRequestURI();  
        int i = uri.indexOf("login");
        boolean b = false;
        if(i > 0) {
        	b = true;
        }
     
        if ( obj == null && !b){
           
            response.sendRedirect("/staff/loginstu");
            return false; 
        }
     
        return true;
    }
  
   
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
        // TODO Auto-generated method stub
        super.postHandle(request, response, handler, modelAndView);
    }     
}
