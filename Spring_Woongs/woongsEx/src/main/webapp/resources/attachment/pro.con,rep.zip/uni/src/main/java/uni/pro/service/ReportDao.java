package uni.pro.service;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import uni.pro.model.ReportDto;





public class ReportDao extends SqlSessionDaoSupport {

	public List <ReportDto>sublist(){
		return getSqlSession().selectList("report.sublist");
		}//과목목록
	public List<ReportDto> reportall(String sub_cd){
		return  getSqlSession().selectList("report.reportall",sub_cd);		
	}//과제목록

	public HashMap<String,Object> viewreport(int stu_no) {
		return getSqlSession().selectOne("report.viewreport",stu_no);
	}// 상세목록
	  public List<ReportDto> downreport(ReportDto dto) throws Exception {  
	        return getSqlSession().selectList("report.down",dto);
	    }
		public int reporteok(int  stu_no){
			return getSqlSession().update("report.ok", stu_no);
		}
	  
}
