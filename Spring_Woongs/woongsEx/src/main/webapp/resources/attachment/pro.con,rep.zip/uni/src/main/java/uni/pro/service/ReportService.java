package uni.pro.service;


import java.io.File;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import uni.pro.model.ReportDto;


@Service
public class ReportService {
@Autowired
	ReportDao dao;
public void setdao(ReportDao dao) {
	this.dao=dao;	
}
public List<ReportDto> sublist(){
	return  dao.sublist();
}

public List<ReportDto>reportall(String sub_cd){
		return dao.reportall(sub_cd);
}
public List<Object>  viewreport(int stu_no) {
	List<Object> list = new ArrayList<>(); 
	list.add(dao.viewreport(stu_no));
	return list;
}
public List<Object> downreport(ReportDto dto) throws Exception {
    List<Object> reportFileList = new ArrayList<>();
    String report_file = null;
 // 설정한 Path에 파일 저장
    ReportDto report = new ReportDto();
    report.setReport_file(report_file);
    reportFileList.add(dao.downreport(dto));

    return reportFileList;
}
public  int reportok(int stu_no) {
return dao.reporteok(stu_no);
	


}
}

