package uni.pro.model;

import java.util.Date;


public class CounselingDto {
   int cs_no;
	String sub_cd;
	Date cs_date;
	int stu_no;
	String stu_name;
	String cs_nm;
	public int getCs_no() {
		return cs_no;
	}
	public void setCs_no(int cs_no) {
		this.cs_no = cs_no;
	}
	public String getSub_cd() {
		return sub_cd;
	}
	public void setSub_cd(String sub_cd) {
		this.sub_cd = sub_cd;
	}
	public Date getCs_date() {
		return cs_date;
	}
	public void setCs_date(Date cs_date) {
		this.cs_date = cs_date;
	}
	public int getStu_no() {
		return stu_no;
	}
	public void setStu_no(int stu_no) {
		this.stu_no = stu_no;
	}
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public String getCs_nm() {
		return cs_nm;
	}
	public void setCs_nm(String cs_nm) {
		this.cs_nm = cs_nm;
	}
	public String getCs_con() {
		return cs_con;
	}
	public void setCs_con(String cs_con) {
		this.cs_con = cs_con;
	}
	public String getCs_state() {
		return cs_state;
	}
	public void setCs_state(String cs_state) {
		this.cs_state = cs_state;
	}
	public String getSub_nm() {
		return sub_nm;
	}
	public void setSub_nm(String sub_nm) {
		this.sub_nm = sub_nm;
	}
	String cs_con;
    String cs_state;
    String sub_nm;

}
