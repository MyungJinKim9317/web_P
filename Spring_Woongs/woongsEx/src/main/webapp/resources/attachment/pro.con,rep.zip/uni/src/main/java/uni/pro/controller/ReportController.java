package uni.pro.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import uni.pro.model.ReportDto;

import uni.pro.service.ReportService;

@Controller
public class ReportController {

	@Autowired
	ReportService service;

	public void setService(ReportService service) {
		this.service = service;
	}

	@RequestMapping(value = "report/reportInfo.do")
	public String sub() throws Exception {
		return "report/reportInfo";
	}

	@RequestMapping(value = "report/reportsub.do", method = RequestMethod.POST)
	@ResponseBody
	public void subList(HttpServletResponse resp) throws Exception {
		List<ReportDto> list = service.sublist();
		Gson json = new Gson();
		resp.setContentType("text/html;charset=utf-8");
		PrintWriter out = resp.getWriter();
		out.print(json.toJson(list));
	}

	@RequestMapping(value = "report/reportall.do", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String reportall(String sub_cd) throws Exception {
		List<ReportDto> list = service.reportall(sub_cd);
		Gson json = new Gson();
		return json.toJson(list);
	}

	@RequestMapping(value = "report/reportform.do", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public ModelAndView reportList(int stu_no) throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("report/reportform");
		mav.addObject("list", service.viewreport(stu_no));
		return mav;
	}
	@RequestMapping("report/download.do")
	public ModelAndView fileDownload(@RequestParam("report_file") String report_file,
			@RequestParam("report_path") String report_path) throws Exception {
		/** 첨부파일 정보 조회 */
		Map<String, Object> down = new HashMap<String, Object>();
		down.put("report_file", report_file);
		down.put("report_path", report_path);
		return new ModelAndView("fileDownloadUtil", "down", down);

	}
	 @RequestMapping(value ="report/reportok.do") 
		public String updatestateok(int  stu_no) { 
			service.reportok(stu_no);
			return "redirect:reportInfo.do";
			}
}