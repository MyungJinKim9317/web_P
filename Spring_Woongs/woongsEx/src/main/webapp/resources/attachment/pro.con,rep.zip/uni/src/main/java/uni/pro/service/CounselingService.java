package uni.pro.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uni.pro.model.CounselingDto;

@Service
public class CounselingService {
	@Autowired
	CounselingDao dao;

	public void setdao(CounselingDao dao) {
		this.dao = dao;
	}

	public List<CounselingDto> sublist() {
		return dao.sublist();
	}

	public List<CounselingDto> conuall(String sub_cd) {
		return dao.conuall(sub_cd);
	}
	public List<Object> viewstucou(int cs_no){
		List<Object> list = new ArrayList<>(); 
		list.add(dao.viewstucou(cs_no));
		return list;
	}
public  int stateok(int  cs_no) {
return dao.stateok( cs_no);
	
}
public  int statenot(int  cs_no) {
return dao.statenot(cs_no);
	
}
public int delete(int cs_no){
	return dao.deletecou(cs_no);
	
}

}
